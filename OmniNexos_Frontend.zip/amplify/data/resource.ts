// amplify/data/resource.ts  (MODIFIED - search "JOBCARD" for the additions)
import { type ClientSchema, a, defineData } from "@aws-amplify/backend";
import { listUsers } from "../function/listUsers/resource";
import { notifyPhotoApproval } from "../function/notifyPhotoApproval/resource";
import { manageUser } from "../function/manageUser/resource";
import { inviteUser } from "../function/inviteUser/resource";
import { jobCardModels } from "./jobcards.models"; // JOBCARD: new job card models
import { listTechnicians } from "../function/listTechnicians/resource"; // JOBCARD: technician picker
import { notifyWorkAssigned } from "../function/notifyWorkAssigned/resource"; // JOBCARD: push when work is assigned

const schema = a.schema({
  ...jobCardModels, // JOBCARD: adds JobCard, JobCardScale, JobCardModule, JobCardSubmission, JobCardTimeEntry, TelegramGroup, CalibrationCertificate, CertificateCounter
  usersList: a
    .query()
    .returns(a.json().array())
    .authorization((allow) => [allow.groups(["ADMINS"])])
    .handler(a.handler.function(listUsers)),

  // JOBCARD: system login users who can be assigned work. Readable by any signed-in user, unlike
  // usersList (admins only). Returns only id, name and email of enabled users.
  TechnicianUser: a.customType({
    id: a.string().required(),
    name: a.string().required(),
    email: a.string(),
  }),
  techniciansList: a
    .query()
    .returns(a.ref("TechnicianUser").array())
    .authorization((allow) => [allow.authenticated()])
    .handler(a.handler.function(listTechnicians)),

  // JOBCARD: push notification to a technician when work is assigned to them. Like notifyPhotoRequestStatus, the caller
  // looks up the technician's push tokens first (pushTokensByUser) and passes them in.
  notifyWorkAssigned: a
    .mutation()
    .arguments({
      pushTokens: a.string().array().required(),
      workItemId: a.string().required(),
      jobCardId: a.string().required(),
      jcNumber: a.string().required(),
      scaleName: a.string().required(),
      workItemLabel: a.string().required(),
    })
    .returns(a.json())
    .authorization((allow) => [allow.authenticated()])
    .handler(a.handler.function(notifyWorkAssigned)),

  notifyPhotoRequestStatus: a
    .mutation()
    .arguments({
      pushTokens: a.string().array().required(),
      status: a.string().required(), // "APPROVED" | "DENIED"
    })
    .returns(a.json())
    .authorization((allow) => [allow.authenticated()])
    .handler(a.handler.function(notifyPhotoApproval)),

  // General account control (offboarding, temporarily blocking a user,
  // permanent removal). No longer tied to a signup-approval flow.
  manageUserAccount: a
    .mutation()
    .arguments({
      username: a.string().required(),
      action: a.string().required(), // "ENABLE" | "DISABLE" | "DELETE"
    })
    .returns(a.json())
    .authorization((allow) => [allow.groups(["ADMINS"])])
    .handler(a.handler.function(manageUser)),

  // Admin-initiated onboarding for non-company people (contractors,
  // clients). Creates the Cognito user directly and emails them a
  // temporary password — no self-signup involved.
  inviteUserAccount: a
    .mutation()
    .arguments({
      email: a.string().required(),
      name: a.string().required(),
    })
    .returns(
      a.customType({
        success: a.boolean().required(),
        reason: a.string(),
      }),
    )
    .authorization((allow) => [allow.groups(["ADMINS"])])
    .handler(a.handler.function(inviteUser)),

  Landing: a
    .model({
      key: a.string(),
      items: a.string(),
    })
    .authorization((allow) => [allow.authenticated()]),
  Category: a
    .model({
      categoryName: a.string().required(),
      subcategories: a.hasMany("SubCategory", "categoryId"),
    })
    .authorization((allow) => [allow.authenticated()])
    .secondaryIndexes((index) => [index("categoryName")]),

  SubCategory: a
    .model({
      subcategoryName: a.string().required(),
      categoryId: a.string().required(),
      category: a.belongsTo("Category", "categoryId"),
      components: a.hasMany("Component", "subcategoryId"),
    })
    .secondaryIndexes((index) => [
      index("categoryId")
        .sortKeys(["subcategoryName"])
        .queryField("listSubCategoriesByCategoryIdAndName"),
    ])
    .authorization((allow) => [allow.authenticated()]),

  Component: a
    .model({
      componentId: a.string().required(),
      componentName: a.string(),
      description: a.string(),
      primarySupplierId: a.string(),
      primarySupplier: a.string(),
      primarySupplierItemCode: a.string(),
      secondarySupplierId: a.string(),
      secondarySupplier: a.string(),
      secondarySupplierItemCode: a.string(),
      minimumStock: a.integer(),
      currentStock: a.integer(),
      notes: a.string(),
      subcategoryId: a.string().required(),
      subcategory: a.belongsTo("SubCategory", "subcategoryId"),
    })
    .secondaryIndexes((index) => [
      index("subcategoryId")
        .sortKeys(["componentId"])
        .queryField("listComponentsBySubCategoryId"),
      index("primarySupplierId")
        .sortKeys(["componentId"])
        .queryField("listComponentsByPrimarySupplier"),
    ])
    .authorization((allow) => [allow.authenticated()]),

  Fleet: a
    .model({
      vehicleVin: a.string(),
      vehicleReg: a.string(),
      vehicleMake: a.string(),
      vehicleModel: a.string(),
      transmitionType: a.string(),
      ownershipStatus: a.string(),
      fleetIndex: a.string(),
      fleetNumber: a.string(),
      lastServicedate: a.date(),
      lastServicekm: a.float(),
      lastRotationdate: a.date(),
      lastRotationkm: a.float(),
      servicePlanStatus: a.boolean(),
      servicePlan: a.string(),
      currentDriver: a.string(),
      currentkm: a.float(),
      codeRequirement: a.string(),
      pdpRequirement: a.boolean(),
      breakandLuxTest: a.string(),
      serviceplankm: a.float(),
      breakandLuxExpirey: a.date(),
      liscenseDiscExpirey: a.date(),
      inspection: a.hasMany("Inspection", "fleetid"),
    })
    .authorization((allow) => [allow.authenticated()]),

  Inspection: a
    .model({
      fleetid: a.string().required(),
      inspectionNo: a.integer(),
      vehicleVin: a.string(),
      inspectionDate: a.date(),
      inspectionTime: a.time(),
      odometerStart: a.float(),
      vehicleReg: a.string(),
      inspectorOrDriver: a.string(),
      oilAndCoolant: a.boolean(),
      fuelLevel: a.boolean(),
      seatbeltDoorsMirrors: a.boolean(),
      handbrake: a.boolean(),
      tyreCondition: a.boolean(),
      spareTyre: a.boolean(),
      numberPlate: a.boolean(),
      licenseDisc: a.boolean(),
      leaks: a.boolean(),
      lights: a.boolean(),
      defrosterAircon: a.boolean(),
      emergencyKit: a.boolean(),
      clean: a.boolean(),
      warnings: a.boolean(),
      windscreenWipers: a.boolean(),
      serviceBook: a.boolean(),
      siteKit: a.boolean(),
      photo: a.string().array(),
      history: a.string(),
      fleet: a.belongsTo("Fleet", "fleetid"),
    })
    .secondaryIndexes((index) => [
      index("fleetid")
        .sortKeys(["inspectionDate"])
        .queryField("inspectionsByFleetAndDate"),
      index("fleetid")
        .sortKeys(["inspectionNo"])
        .queryField("inspectionsByFleetAndNumber"),
    ])
    .authorization((allow) => [allow.authenticated()]),

  TaskTable: a
    .model({
      vehicleReg: a.string().required(),
      taskType: a.enum(["service", "rotation", "licensedisc", "breaknlux"]),
      clickupTaskId: a.string(), // Store ClickUp task ID for reference
    })
    .secondaryIndexes((index) => [
      index("vehicleReg").sortKeys(["taskType"]), // Check if task exists for vehicle+type
      index("clickupTaskId"),
    ])
    .authorization((allow) => [allow.authenticated()]),

  EmployeeTaskTable: a
    .model({
      employeeId: a.string().required(),
      employeeName: a.string().required(),
      taskType: a.string().required(),
      documentType: a.string().required(),
      documentIdentifier: a.string().required(),
      clickupTaskId: a.string(),
    })
    .secondaryIndexes((index) => [
      index("employeeId")
        .sortKeys(["employeeName"])
        .queryField("listEmployeeTaskTableByEmployeeIdAndEmployeeName"),
      index("employeeId"),
      index("taskType"),
      index("documentIdentifier"),
      index("clickupTaskId"),
    ])
    .authorization((allow) => [allow.authenticated()]),

  Employee: a
    .model({
      employeeId: a.string().required(),
      employeeNumber: a.string(),
      firstName: a.string().required(),
      surname: a.string().required(),
      employeeIdAttachment: a.string(),
      knownAs: a.string(),
      passportNumber: a.string(),
      passportExpiry: a.date(),
      passportAttachment: a.string(),
      driversLicenseCode: a.string(),
      driversLicenseExpiry: a.date(),
      driversLicenseAttachment: a.string(),
      authorizedDriver: a.boolean(),
      pdpExpiry: a.date(),
      pdpAttachment: a.string(),
      referencePhotoKey: a.string(), //new addition for employee photo reference
      // Core documents
      cvAttachment: a.string(),
      ppeListAttachment: a.string(),
      ppeExpiry: a.date(),
      // Medical certificates as relations
      medicalCertificates: a.hasMany(
        "EmployeeMedicalCertificate",
        "employeeId",
      ),
      // Training certificates as relations
      trainingCertificates: a.hasMany(
        "EmployeeTrainingCertificate",
        "employeeId",
      ),
      // Additional certificates
      additionalCertificates: a.hasMany(
        "EmployeeAdditionalCertificate",
        "employeeId",
      ),
    })
    .secondaryIndexes((index) => [
      index("employeeId"),
      index("employeeNumber"),
      index("driversLicenseExpiry").queryField("employeesByLicenseExpiry"),
      index("passportExpiry").queryField("employeesByPassportExpiry"),
    ])
    .authorization((allow) => [allow.authenticated()]),

  EmployeeMedicalCertificate: a
    .model({
      employeeId: a.string().required(),
      certificateType: a.enum([
        "CLINIC_PLUS",
        "CLINIC_PLUS_INDUCTION",
        "HEARTLY_HEALTH",
        "KLIPSPRUIT_MEDICAL",
        "LUYUYO_MEDICAL",
        "KRIEL_MEDICAL",
        "PRO_HEALTH_MEDICAL",
        "WILGE_VXR",
      ]),
      expiryDate: a.date().required(),
      attachment: a.string(),
      employee: a.belongsTo("Employee", "employeeId"),
    })
    .secondaryIndexes((index) => [
      index("employeeId")
        .sortKeys(["expiryDate"])
        .queryField("medicalCertsByEmployee"),
      index("expiryDate").queryField("medicalCertsByExpiry"),
    ])
    .authorization((allow) => [allow.authenticated()]),

  EmployeeTrainingCertificate: a
    .model({
      employeeId: a.string().required(),
      certificateType: a.enum([
        "FIREFIGHTING",
        "FIRST_AID_LEVEL_1",
        "FIRST_AID_LEVEL_2",
        "WORKING_AT_HEIGHTS",
        "WORKING_WITH_HAND_TOOLS",
        "WORKING_WITH_POWER_TOOLS",
        "SATS_CONVEYOR",
        "SATS_COP_SOP",
        "SATS_ILOT",
        "OHS_ACT",
        "MHSA",
        "HIRA_TRAINING",
        "APPOINTMENT_2_9_2",
        "OEM_CERT",
        "LEGAL_LIABILITY",
      ]),
      expiryDate: a.date().required(),
      attachment: a.string(),
      employee: a.belongsTo("Employee", "employeeId"),
    })
    .secondaryIndexes((index) => [
      index("employeeId")
        .sortKeys(["expiryDate"])
        .queryField("trainingCertsByEmployee"),
      index("expiryDate").queryField("trainingCertsByExpiry"),
      index("certificateType").queryField("trainingCertsByType"),
    ])
    .authorization((allow) => [allow.authenticated()]),

  EmployeeAdditionalCertificate: a
    .model({
      employeeId: a.string().required(),
      certificateName: a.string().required(),
      expiryDate: a.date().required(),
      attachment: a.string(),
      employee: a.belongsTo("Employee", "employeeId"),
    })
    .secondaryIndexes((index) => [
      index("employeeId")
        .sortKeys(["expiryDate"])
        .queryField("additionalCertsByEmployee"),
      index("expiryDate").queryField("additionalCertsByExpiry"),
    ])
    .authorization((allow) => [allow.authenticated()]),

  EmployeeAdditionalList: a
    .model({
      certificateName: a.string().required(),
    })
    .authorization((allow) => [allow.authenticated()]),

  History: a
    .model({
      entityType: a.enum([
        "COMPONENT",
        "FLEET",
        "INSPECTION",
        "EMPLOYEE",
        "CUSTOMER",
        "ASSET",
        "COMPLIANCE",
        "PERMISSIONS",
        "SUPPLIER",
        "JOBCARD", // JOBCARD: new History entity type
      ]),
      entityId: a.string().required(),
      action: a.string().required(),
      timestamp: a.datetime().required(),
      updatedBy: a.string(),
      details: a.string().required(),
    })
    .secondaryIndexes((index) => [
      index("entityId")
        .sortKeys(["timestamp"])
        .queryField("getHistoryByEntityId"),
      index("updatedBy")
        .sortKeys(["timestamp"])
        .queryField("getHistoryByUpdatedBy"),
    ])
    .authorization((allow) => [allow.authenticated()]),

  CustomerSite: a
    .model({
      // Site Information
      siteName: a.string().required(),
      siteLocation: a.string(),
      siteDistance: a.float(),
      siteTolls: a.float(),

      // Customer Company Information
      customerName: a.string().required(),
      registrationNo: a.string(),
      vatNo: a.string(),
      vendorNumber: a.string(),
      postalAddress: a.string(),
      physicalAddress: a.string(),

      // Contact Information - all embedded
      siteContactName: a.string(),
      siteContactMail: a.string(),
      siteContactNumber: a.string(),

      siteManagerName: a.string(),
      siteManagerMail: a.string(),
      siteManagerNumber: a.string(),

      siteSafetyName: a.string(),
      siteSafetyMail: a.string(),
      siteSafetyNumber: a.string(),

      siteProcurementName: a.string(),
      siteProcurementMail: a.string(),
      siteProcurementNumber: a.string(),

      siteCreditorsName: a.string(),
      siteCreditorsMail: a.string(),
      siteCreditorsNumber: a.string(),
      assets: a.hasMany("Asset", "customerSiteId"),
      compliance: a.hasMany("Compliance", "customerSiteId"),
      comment: a.string(),
    })
    .secondaryIndexes((index) => [
      index("customerName"),
      index("siteName"),
      index("vendorNumber"),
      index("registrationNo"),
    ])
    .authorization((allow) => [allow.authenticated()]),

  Asset: a
    .model({
      assetName: a.string().required(),
      assetPlant: a.string(),
      scaleTag: a.string(),
      scaleOEM: a.string(),
      beltwidth: a.string(),
      troughAngle: a.string(),
      scaleModel: a.string(),
      weighIdlerQTY: a.string(),
      approachIdlerQTY: a.string(),
      retreatIdlerQTY: a.string(),
      centerRollSize: a.string(),
      wingRollSize: a.string(),
      loadcellType: a.string(),
      loadcellQTY: a.string(),
      loadcellSize: a.string(),
      integratorOEM: a.string(),
      integratorModel: a.string(),
      ssrOEM: a.string(),
      ssrModel: a.string(),
      scaledatasheetAttach: a.string(),
      submittedmaintplanAttach: a.string(),
      notes: a.string(),
      customerSiteId: a.id().required(),
      customerSite: a.belongsTo("CustomerSite", "customerSiteId"),
    })
    .secondaryIndexes((index) => [index("customerSiteId"), index("scaleTag")])
    .authorization((allow) => [allow.authenticated()]),

  Compliance: a
    .model({
      complianceRating: a.string(),
      complianceRating30Days: a.string(),
      linkedEmployees: a.string().array(),
      digitalContractorsPack: a.string().array(),
      notes: a.string(),
      // Requirement arrays - Employee IDs who need these documents
      clinicPlusRqd: a.string().array(),
      clinicPlusInductionRqd: a.string().array(),
      driversLicenseRqd: a.string().array(),
      firefightingRqd: a.string().array(),
      firstAidLevel1Rqd: a.string().array(),
      firstAidLevel2Rqd: a.string().array(),
      heartlyHealthRqd: a.string().array(),
      klipspruitMedicalRqd: a.string().array(),
      legalLiabilityRqd: a.string().array(),
      luvuyoMedicalRqd: a.string().array(),
      oemCertRqd: a.string().array(),
      passportRqd: a.string().array(),
      pdpRqd: a.string().array(),
      satsConveyorRqd: a.string().array(),
      satsCopSopRqd: a.string().array(),
      wilgeVxrRqd: a.string().array(),
      workingAtHeightsRqd: a.string().array(),
      workingWithHandToolsRqd: a.string().array(),
      workingWithPowerToolsRqd: a.string().array(),
      appointment292Rqd: a.string().array(),
      curriculumVitaeRqd: a.string().array(),
      ppeListRqd: a.string().array(),
      ohsActRqd: a.string().array(),
      mhsaRqd: a.string().array(),
      krielMedicalRqd: a.string().array(),
      proHealthMedicalRqd: a.string().array(),
      satsIlotRqd: a.string().array(),
      hiraTrainingRqd: a.string().array(),

      // Linked vehicles section
      linkedVehicles: a.string().array(),
      breakAndLuxRqd: a.string().array(),
      licenseDiscExpiry: a.string().array(),

      customerSiteId: a.id().required(),
      customerSite: a.belongsTo("CustomerSite", "customerSiteId"),

      // CHANGE TO STRING:
      employeeLookup: a.string(), // Store as JSON string: '{"employeeId": ["req1", "req2"]}'
      ComplianceAdditionals: a.hasMany("ComplianceAdditionals", "complianceid"),
    })
    .secondaryIndexes((index) => [
      index("customerSiteId"),
      index("complianceRating"),
      index("employeeLookup"),
    ])
    .authorization((allow) => [allow.authenticated()]),

  ComplianceAdditionals: a
    .model({
      complianceid: a.id().required(),
      name: a.string(),
      expirey: a.string(),
      requirementDoc: a.string(),
      critical: a.string(),
      Compliance: a.belongsTo("Compliance", "complianceid"),
    })
    .secondaryIndexes((index) => [index("name"), index("complianceid")])
    .authorization((allow) => [allow.authenticated()]),

  Permission: a
    .model({
      userId: a.string().required(),
      permissions: a.string().array(), // ["hrd.edit", "crm.assets.view"]
    })
    .authorization((allow) => [allow.authenticated()])
    .secondaryIndexes((index) => [index("userId")]),

  XeroContacts: a
    .model({
      contactId: a.string().required(),
      contactName: a.string(),
      contactTaxNo: a.string(),
      contactRegNo: a.string(),
      suppliers: a.hasMany("Supplier", "xeroContactId"),
    })
    .authorization((allow) => [allow.authenticated()])
    .secondaryIndexes((index) => [index("contactId"), index("contactName")]),

  Supplier: a
    .model({
      xeroContactId: a.string().required(),
      xeroContact: a.belongsTo("XeroContacts", "xeroContactId"),

      supplierAddress: a.string(),
      primaryName: a.string(),
      primaryEmail: a.email(),
      primaryCell: a.phone(),

      secondaryName: a.string(),
      secondaryEmail: a.email(),
      secondaryCell: a.phone(),

      doesDeliver: a.boolean(),
      aveLeadTime: a.integer(), //B_Days
      accountType: a.enum([
        //single select [100% in advance ,Deposit requirement ,Cash on collection ,X Day Account]
        "ADVANCE",
        "DEPOSIT",
        "CASH_ON_COLLECTION",
        "X_DAY_ACCOUNT",
      ]),
      paymentDelay: a.integer(),
      discountAvailable: a.boolean(),
      discountAmt: a.string(),
      discountNote: a.string(),
      notes: a.string(),
    })
    .authorization((allow) => [allow.authenticated()])
    .secondaryIndexes((index) => [index("xeroContactId")]),
  xeroConfig: a
    .model({
      tenantId: a.string().required(),
      quotesLastSyncUTC: a.datetime(),
      purchasesLastSyncUTC: a.datetime(),
      refreshTokenEncrypted: a.string(),
    })
    .authorization((allow) => [allow.authenticated()])
    .secondaryIndexes((index) => [index("tenantId")]),

  Quote: a
    .model({
      quoteId: a.string().required(),
      quoteNumber: a.string(),
      quoteReference: a.string(),
      customerID: a.string(),
      customerName: a.string(),
      quoteIssueDate: a.datetime(),
      quoteExpireyDate: a.datetime(),
      quoteStatus: a.string(),
      currencyCode: a.string(),
      lineItems: a.json().array(),
      subTotal: a.float(),
      taxTotal: a.float(),
      quTotal: a.float(),
      title: a.string(),
      PoNumber: a.string(),
      invNumber: a.string(),
      businessUnitvalueid: a.string(),
      businessUnitvalue: a.string(),
      quoteAction: a.string(), //derived state
      clickUpTaskidCrm1: a.string(),
      clickUpTaskidCrm2: a.string(),
      clickUpTaskidCRM032: a.string(),
      clickUpTaskidCRM033: a.string(),
      clickUpTaskidCRM050_Global: a.string(),
      clickUpTaskidCRM050_SERVICES: a.string(),
      clickUpTaskidCRM051_GLOBAL: a.string(),
      clickUpTaskidCRM051_SERVICES: a.string(),
      clickUpTaskidCrm7: a.string(),
      clickUpTaskidCrm9: a.string(),
    })
    .authorization((allow) => [allow.authenticated()])
    .secondaryIndexes((index) => [index("quoteId"), index("quoteNumber")]),

  Invoice: a
    .model({
      invoiceId: a.string().required(), // Xero InvoiceID
      invoiceNumber: a.string(),

      // 🔗 LINK TO QUOTE
      xeroQuoteId: a.string(), // from Xero if available
      quoteNumber: a.string(), // your main link (important)
      reference: a.string(), // usually where quoteNumber can live

      customerID: a.string(),
      customerName: a.string(),

      invoiceDate: a.datetime(),
      dueDate: a.datetime(),

      status: a.string(), // DRAFT / AUTHORISED / PAID etc
      invoiceAction: a.string(), // derived

      currencyCode: a.string(),
      lineItems: a.json().array(),

      subTotal: a.float(),
      taxTotal: a.float(),
      total: a.float(),

      amountPaid: a.float(),
      amountDue: a.float(),

      PoNumber: a.string(),

      businessUnitvalueid: a.string(),
      businessUnitvalue: a.string(),
      // reuse your CRM links
      clickUpTaskidCrm1: a.string(),
      clickUpTaskidCrm2: a.string(),
      clickUpTaskidCrm5: a.string(),
      clickUpTaskidCrm7: a.string(),
      clickUpTaskidCrm9: a.string(),
    })
    .authorization((allow) => [allow.authenticated()])
    .secondaryIndexes((index) => [
      index("invoiceId"),
      index("invoiceNumber"),
      index("quoteNumber"),
      index("xeroQuoteId"),
    ]),
  // ── Photo change request — user submits, admin approves ───────────────────
  PhotoChangeRequestStatus: a.enum([
    "PENDING",
    "APPROVED",
    "DENIED",
    "COMPLETED",
  ]),

  PhotoChangeRequest: a
    .model({
      userId: a.string().required(),
      employeeName: a.string(),
      status: a.ref("PhotoChangeRequestStatus").required(),
      requestedAt: a.datetime(),
      reviewedAt: a.datetime(),
      reviewedBy: a.string(), // admin email
    })
    .secondaryIndexes((index) => [
      index("userId")
        .sortKeys(["requestedAt"])
        .queryField("photoRequestsByUserAndDate"),
      index("status")
        .sortKeys(["requestedAt"])
        .queryField("photoRequestsByStatus"),
    ])
    .authorization((allow) => [allow.authenticated()]),

  // ── Push token — stores device push tokens for notifications ─────────────
  PushToken: a
    .model({
      userId: a.string().required(),
      token: a.string().required(),
      platform: a.enum(["ios", "android", "web"]),
      updatedAt: a.datetime(),
    })
    .secondaryIndexes((index) => [
      index("userId").queryField("pushTokensByUser"),
    ])
    .authorization((allow) => [allow.authenticated()]),

  ClockRecordStatus: a.enum([
    "VERIFIED",
    "PENDING_VERIFICATION",
    "REVIEW_REQUIRED",
  ]),

  ClockRecord: a
    .model({
      userId: a.string().required(),
      employeeName: a.string().required(),
      clockInTime: a.datetime().required(),
      clockOutTime: a.datetime(),
      hoursWorked: a.float(),
      clockInLat: a.float(),
      clockInLng: a.float(),
      clockOutLat: a.float(),
      clockOutLng: a.float(),
      clockInAddress: a.string(),
      clockOutAddress: a.string(),
      verificationStatus: a.ref("ClockRecordStatus").required(),
      similarityScore: a.float(),
      syncedOffline: a.boolean().required(),
      localSelfieUri: a.string(), // temp local path — cleared after S3 sync
      date: a.date().required(), // YYYY-MM-DD — for date-range queries
    })
    .secondaryIndexes((index) => [
      index("userId")
        .sortKeys(["clockInTime"])
        .queryField("clockRecordsByUserAndTime"),
      index("date").sortKeys(["clockInTime"]).queryField("clockRecordsByDate"),
    ])
    .authorization((allow) => [allow.authenticated()]),
});

export type Schema = ClientSchema<typeof schema>;

export const data = defineData({
  schema,
  authorizationModes: {
    defaultAuthorizationMode: "userPool",
  },
});