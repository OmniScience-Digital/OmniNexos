// amplify/storage/resource.ts  (MODIFIED - search "JOBCARD" for the addition)
// amplify/storage.ts
import { defineStorage } from '@aws-amplify/backend';

export const storage = defineStorage({
  name: 'OmniNexos_Storage',
  access: (allow) => ({
    "inspections/*": [
      // Explicitly specify the group
      allow.groups(["USERS"]).to(['read', 'write', 'delete']),
      allow.groups(["ADMINS"]).to(['read', 'write', 'delete'])
    ],
    "documents/*": [
      allow.groups(["USERS"]).to(['read', 'write', 'delete']),
      allow.groups(["ADMINS"]).to(['read', 'write', 'delete'])
    ],
    // JOBCARD: result photos and calibration certificates, stored as jobcards/{jobCardId}/...
    "jobcards/*": [
      allow.groups(["USERS"]).to(['read', 'write']),
      allow.groups(["ADMINS"]).to(['read', 'write', 'delete'])
    ],
    "hr/*": [
      allow.groups(["USERS"]).to(['read', 'write', 'delete']),
      allow.groups(["ADMINS"]).to(['read', 'write', 'delete'])
    ],
  })
});